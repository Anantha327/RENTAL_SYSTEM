CREATE TABLE `bikes` (
  `Brand` varchar(45) NOT NULL,
  `Mielage` varchar(45) NOT NULL,
  `Engine` varchar(45) NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Brand`)
) ;
INSERT INTO `rental_systems`.`bikes` (`Brand`, `Mileage`, `Engine`, `Rent`) VALUES ('Hero Honda', '70 km/litre', '97.2 cc', '2000/hr');
INSERT INTO `rental_systems`.`bikes` (`Brand`, `Mileage`, `Engine`, `Rent`) VALUES ('Pulsar', '35-55 km/litre', '149.5  cc', '1800 /hr');
INSERT INTO `rental_systems`.`bikes` (`Brand`, `Mileage`, `Engine`, `Rent`) VALUES ('Royal Enfield', '37 km/litre', '346 cc', '4000 /hr');

CREATE TABLE `bicycles` (
  `Brand` varchar(45) NOT NULL,
  `Speed Rating` int NOT NULL,
  `Style` varchar(45) NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Brand`)
);

INSERT INTO `rental_systems`.`bicycles` (`Brand`, `Speed Rating`, `Style`, `Rent`) VALUES ('Hero', '21', 'All mountain', '1500 /hr');
INSERT INTO `rental_systems`.`bicycles` (`Brand`, `Speed Rating`, `Style`, `Rent`) VALUES ('Hercules', '21', 'All mountains', '1700 /hr');
INSERT INTO `rental_systems`.`bicycles` (`Brand`, `Speed Rating`, `Style`, `Rent`) VALUES ('Dexter', '21', 'All mountain', '1650 /hr');
CREATE TABLE `cars` (
  `Brand` varchar(45) NOT NULL,
  `Mileage` varchar(45) NOT NULL,
  `Engine` varchar(45) NOT NULL,
  `Transmission` varchar(45) NOT NULL,
  `Seats` int NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Brand`)
) ;
INSERT INTO `rental_systems`.`cars` (`Brand`, `Mileage`, `Engine`, `Transmission`, `Seats`, `Rent`) VALUES ('Honda City', '32.48 km/kg', '1498 cc', 'Manual', '5', '2500 /hr');
INSERT INTO `rental_systems`.`cars` (`Brand`, `Mileage`, `Engine`, `Transmission`, `Seats`, `Rent`) VALUES ('Hyundai', '18.6 km/litre', '1197 cc', 'Manual', '5', '2300/hr');
INSERT INTO `rental_systems`.`cars` (`Brand`, `Mileage`, `Engine`, `Transmission`, `Seats`, `Rent`) VALUES ('Suzuki', '30.48 km/kg', '1086 cc', 'Manual / Automatic', '5', '2000 /hr');
CREATE TABLE `desktops` (
  `Brand` varchar(45) NOT NULL,
  `Screen Display Size` varchar(45) NOT NULL,
  `Processor` varchar(45) NOT NULL,
  `Ram` varchar(45) NOT NULL,
  `OS` varchar(45) NOT NULL,
  `Hard Drive` varchar(45) NOT NULL,
  `Hard Disk` varchar(45) NOT NULL,
  `Graphics` varchar(45) NOT NULL,
  `Includes` varchar(500) NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Brand`)
) ;
INSERT INTO `rental_systems`.`desktops` (`Brand`, `Screen Display Size`, `Processor`, `Ram`, `OS`, `Hard Drive`, `Hard Disk`, `Graphics`, `Includes`, `Rent`) VALUES ('Acer', '18.5 inches', 'Intel i3 of speed 3.9GHz', '8 GB', 'Windows/Linux', '2 TB', 'HDD', 'Intel HD Graphics', 'Wireless keyboard, PowerCable, wired mouse, CPU', '8000 /hr');
INSERT INTO `rental_systems`.`desktops` (`Brand`, `Screen Display Size`, `Processor`, `Ram`, `OS`, `Hard Drive`, `Hard Disk`, `Graphics`, `Includes`, `Rent`) VALUES ('Asus', '21.5 inches', 'Intel i5 of speed 1.6 GHz', '8 GB', 'Windows', '1 TB', 'HDD', 'Radeon', 'Wired keyboard, Power Cable, wired mouse', '6000/hr');
INSERT INTO `rental_systems`.`desktops` (`Brand`, `Screen Display Size`, `Processor`, `Ram`, `OS`, `Hard Drive`, `Hard Disk`, `Graphics`, `Includes`, `Rent`) VALUES ('Lenovo', '23.8 inches', 'Intel i7 of speed 1.6 GHz', '16 GB', 'Windows', '1 TB', 'HDD', 'Intel UHD Graphics', 'Wireless keyboard, Power Cable, Wireless mouse', '10000 /hr');
CREATE TABLE `dumbell` (
  `Brand` varchar(45) NOT NULL,
  `Size` varchar(45) NOT NULL,
  `Usage` varchar(45) NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Brand`)
) ;
INSERT INTO `rental_systems`.`dumbell` (`Brand`, `Size`, `Usage`, `Rent`) VALUES ('Giovane', '5 kg', 'Home Gym', '300 /hr');
INSERT INTO `rental_systems`.`dumbell` (`Brand`, `Size`, `Usage`, `Rent`) VALUES ('J Marque', '2 kg', 'Home Gym', '500/hr');
INSERT INTO `rental_systems`.`dumbell` (`Brand`, `Size`, `Usage`, `Rent`) VALUES ('Kore', '20 kg', 'Home Gym', '1000 /hr');
CREATE TABLE `individual_house` (
  `Type` varchar(45) NOT NULL,
  `Rooms` int NOT NULL,
  `Area` varchar(45) NOT NULL,
  `Address` varchar(400) NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Type`)
);
INSERT INTO `rental_systems`.`individual_house` (`Type`, `Rooms`, `Area`, `Address`, `Rent`) VALUES ('individual', '6', '1000 sqft', 'Near Buddhist artifacts, Nampally Hyderabad, Telangana 500004', '23000');
INSERT INTO `rental_systems`.`individual_house` (`Type`, `Rooms`, `Area`, `Address`, `Rent`) VALUES ('own house', '4', '5000 sqft', 'Near to Birla Mandir, Ambedkar Colony, Khairatabad, Hyderabad, Telengana, 500004', '23000');
INSERT INTO `rental_systems`.`individual_house` (`Type`, `Rooms`, `Area`, `Address`, `Rent`) VALUES ('seperate house', '6', '8000 sqft', 'Sardar Patel Road, Ameerpet, Hyderabad, Telegana, 500004', '23000');
CREATE TABLE `laptops` (
  `Brand` varchar(45) NOT NULL,
  `Processor` varchar(45) NOT NULL,
  `Speakers` varchar(45) NOT NULL,
  `Ram` varchar(45) NOT NULL,
  `Graphics` varchar(45) NOT NULL,
  `Ports` varchar(45) NOT NULL,
  `USB` varchar(200) NOT NULL,
  `OS` varchar(155) NOT NULL,
  `Battery Life` varchar(45) NOT NULL,
  `Include` varchar(45) NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Brand`)
);
INSERT INTO `rental_systems`.`laptops` (`Brand`, `Processor`, `Speakers`, `Ram`, `Graphics`, `Ports`, `USB`, `OS`, `Battery Life`, `Include`, `Rent`) VALUES ('Dell', 'intel i3', 'Waves Max Audio', '8 GB', '5', 'Intel Integrated Audio', 'Microphone-1', '(2.0)-2(3.0)-1 HDMI - 1', 'Windows', '6 hours', 'Laptop Charger', '2500/hr');
INSERT INTO `rental_systems`.`laptops` (`Brand`, `Processor`, `Speakers`, `Ram`, `Graphics`, `Ports`, `USB`, `OS`, `Battery Life`, `Include`, `Rent`) VALUES ('Hp', 'intel i5', 'Waves Max Audio', '8 GB', '5', 'Intel HD Graphics', 'Microphone-1', '2.0 and 2(3.0) 2 HDMI-1', 'Windows/Linux', '4 hours', 'Laptop Charger', '2800/hr');
INSERT INTO `rental_systems`.`laptops` (`Brand`, `Processor`, `Speakers`, `Ram`, `Graphics`, `Ports`, `USB`, `OS`, `Battery Life`, `Include`, `Rent`) VALUES ('Lenovo', 'intel i3', 'Waves Max Audio', '4 GB', '5', 'Intel UHD Graphics', 'Microphone-1', '(2.0) - 2(3.0)-1 HDMI-1', 'DOS/Windows', '4 hours', 'Laptop Charger', '2800/hr');
CREATE TABLE `printer` (
  `Brand` varchar(45) NOT NULL,
  `Functions Supported` varchar(45) NOT NULL,
  `Print Output` varchar(45) NOT NULL,
  `Display type` varchar(45) NOT NULL,
  `Print Speed` varchar(45) NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Brand`)
);
INSERT INTO `rental_systems`.`printer` (`Brand`, `Functions Supported`, `Print Output`, `Display Type`, `Print Speed`, `Rent`) VALUES ('Canon', 'Print, Scan, Copy', 'Color', 'LCD ', '7.7 ppm', '900 /hr');
INSERT INTO `rental_systems`.`printer` (`Brand`, `Functions Supported`, `Print Output`, `Display Type`, `Print Speed`, `Rent`) VALUES ('Epson', 'Print, Scan, Copy', 'Black and white', 'LCD ', '5 ppm', '800/hr');
INSERT INTO `rental_systems`.`printer` (`Brand`, `Functions Supported`, `Print Output`, `Display Type`, `Print Speed`, `Rent`) VALUES ('Hp', 'Print, Copy', 'Color, Black and white', 'LCD', '7 ppm', '600 /hr');
CREATE TABLE `shooting_space` (
  `Address` varchar(700) NOT NULL,
  `Your booking includes` varchar(700) NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Address`)
) ;
INSERT INTO `rental_systems`.`shooting_space` (`Address`, `Your booking includes`, `Rent`) VALUES ('Aparna Towers, 18th floor, Kondapur, Hyderabad, Telangana', 'lighting Equipment, Black out blinds, Chairs, Tables, WIFI, Dressing, Rooms, Computer', '18000 /hr');
INSERT INTO `rental_systems`.`shooting_space` (`Address`, `Your booking includes`, `Rent`) VALUES ('Near Raghavender Park, Sai Towers, ground Floor, Vijayawada, Andhra Pradesh', 'lighting Equipment, Air Conditioning, Black out blinds, Chairs, Tables, WIFI, Dressing Rooms, Computer', '18000/hr');
INSERT INTO `rental_systems`.`shooting_space` (`Address`, `Your booking includes`, `Rent`) VALUES ('third floor, Prabha Nagari Bulding, Andheri, Mumbai, Maharastra', 'lighting Equipment, Air Conditioning, Black out blinds, Chairs, Tables, WIFI, Dressing Rooms, Projector and screen, Mike, Computer', '20000 /hr');
CREATE TABLE `shopping_complex` (
  `Shop number` int NOT NULL,
  `Area` varchar(45) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Rent` int NOT NULL,
  PRIMARY KEY (`Shop number`)
);
INSERT INTO `rental_systems`.`shopping_complex` (`Shop Number`, `Area`, `Address`, `Rent`) VALUES ('5', '500sqft', 'Tirumala, Tirupathi, Andhra Pradesh', '5000');
INSERT INTO `rental_systems`.`shopping_complex` (`Shop Number`, `Area`, `Address`, `Rent`) VALUES ('234', '4500sqft', 'KPHB phase 9, Kukatpally, hyderabad, Telangana - 500085', '15000/hr');
INSERT INTO `rental_systems`.`shopping_complex` (`Shop Number`, `Area`, `Address`, `Rent`) VALUES ('345', '2500sqft', 'Kondapur, Hyderabad, Telangana', '18000 /hr');

CREATE TABLE `spin bike` (
  `Brand` varchar(45) NOT NULL,
  `User Weight` varchar(45) NOT NULL,
  `Adjustable Saddle` varchar(45) NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Brand`)
);
INSERT INTO `rental_systems`.`spin bike` (`Brand`, `User Weight`, `Adustable Saddle`, `Rent`) VALUES ('Avon', '126 kg', 'Horizontal and Vertical', '1800 /hr');
INSERT INTO `rental_systems`.`spin bike` (`Brand`, `User Weight`, `Adustable Saddle`, `Rent`) VALUES ('Mackatoo', '175 kg', 'Horizontal and Vertical', '1600/hr');
INSERT INTO `rental_systems`.`spin bike` (`Brand`, `User Weight`, `Adustable Saddle`, `Rent`) VALUES ('Profit Fitness', '100 kg', 'Horizontal and Vertical', '1500 /hr');

CREATE TABLE `treadmill` (
  `Brand` varchar(45) NOT NULL,
  `Peak power` varchar(45) NOT NULL,
  `User Weight` varchar(45) NOT NULL,
  `Rent` varchar(45) NOT NULL,
  PRIMARY KEY (`Brand`)
);

INSERT INTO `rental_systems`.`treadmill` (`Brand`, `Peak power`, `User Weight`, `Rent`) VALUES ('Afton', '4', '1498 cc', '100 kg', '1600 /hr');
INSERT INTO `rental_systems`.`treadmill` (`Brand`, `Peak power`, `User Weight`, `Rent`) VALUES ('Cackatoo', '5 HP', '1197 cc', '120 kg', '1700/hr');
INSERT INTO `rental_systems`.`treadmill` (`Brand`, `Peak power`, `User Weight`, `Rent`) VALUES ('Fitkit', '3.25 HP', '1086 cc', '110 kg', '1500 /hr');